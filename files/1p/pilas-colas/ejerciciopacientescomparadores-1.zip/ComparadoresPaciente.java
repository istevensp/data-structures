import java.util.Comparator;

public class ComparadoresPaciente {

    public static Comparator<Paciente> porPrioridadYEdad() {
        return Comparator
            .comparing(Paciente::getPrioridad).reversed()
            .thenComparing(Paciente::getEdad, Comparator.reverseOrder());
    }

    public static Comparator<Paciente> porTipoPrioridadEdad() {
        return Comparator
            .comparing(Paciente::getTipo)
            .thenComparing(Paciente::getPrioridad, Comparator.reverseOrder())
            .thenComparing(Paciente::getEdad);
    }

    public static Comparator<Paciente> porTipoPrioridadEdadNombre() {
        return Comparator
            .comparing(Paciente::getTipo)
            .thenComparing(Paciente::getPrioridad, Comparator.reverseOrder())
            .thenComparing(Paciente::getEdad)
            .thenComparing(Paciente::getNombre);
    }
}