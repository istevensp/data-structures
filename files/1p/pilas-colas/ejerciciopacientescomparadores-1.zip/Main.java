import java.util.*;

public class Main {
    public static void main(String[] args) {
        Map<Integer, Paciente> pacientesMap = new HashMap<>();

        Paciente p1 = new Paciente(1, "Ana", 30, "NORMAL", 3);
        Paciente p2 = new Paciente(2, "Luis", 65, "URGENTE", 5);
        Paciente p3 = new Paciente(3, "Bea", 50, "NORMAL", 2);
        Paciente p4 = new Paciente(4, "Carlos", 40, "URGENTE", 5);
        Paciente p5 = new Paciente(5, "Eva", 70, "NORMAL", 4);

        pacientesMap.put(p1.getId(), p1);
        pacientesMap.put(p2.getId(), p2);
        pacientesMap.put(p3.getId(), p3);
        pacientesMap.put(p4.getId(), p4);
        pacientesMap.put(p5.getId(), p5);

        Comparator<Paciente> ordenNaturalPorID = new Comparator<Paciente>() {
            @Override
            public int compare(Paciente o1, Paciente o2) {
                return Integer.compare(o1.getId(), o2.getId());
            }
        };

        System.out.println("--- Orden natural (por ID) ---");
        PriorityQueue<Paciente> cola1 = new PriorityQueue<>(ordenNaturalPorID);
        cola1.addAll(pacientesMap.values());
        while (!cola1.isEmpty()) {
            System.out.println(cola1.poll());
        }

        System.out.println("\n--- Por prioridad y edad ---");
        PriorityQueue<Paciente> cola2 = new PriorityQueue<>(ComparadoresPaciente.porPrioridadYEdad());
        cola2.addAll(pacientesMap.values());
        while (!cola2.isEmpty()) {
            System.out.println(cola2.poll());
        }

        System.out.println("\n--- Por tipo, prioridad y edad ---");
        PriorityQueue<Paciente> cola3 = new PriorityQueue<>(ComparadoresPaciente.porTipoPrioridadEdad());
        cola3.addAll(pacientesMap.values());
        while (!cola3.isEmpty()) {
            System.out.println(cola3.poll());
        }

        System.out.println("\n--- Por tipo, prioridad, edad y nombre ---");
        PriorityQueue<Paciente> cola4 = new PriorityQueue<>(ComparadoresPaciente.porTipoPrioridadEdadNombre());
        cola4.addAll(pacientesMap.values());
        while (!cola4.isEmpty()) {
            System.out.println(cola4.poll());
        }
    }
}