public class Paciente {
    private int id;
    private String nombre;
    private int edad;
    private String tipo;
    private int prioridad;

    public Paciente(int id, String nombre, int edad, String tipo, int prioridad) {
        this.id = id;
        this.nombre = nombre;
        this.edad = edad;
        this.tipo = tipo;
        this.prioridad = prioridad;
    }

    public int getId() { return id; }
    public String getNombre() { return nombre; }
    public int getEdad() { return edad; }
    public String getTipo() { return tipo; }
    public int getPrioridad() { return prioridad; }

    @Override
    public String toString() {
        return "[" + id + ", " + nombre + ", " + edad + " años, " + tipo + ", prioridad " + prioridad + "]";
    }
}